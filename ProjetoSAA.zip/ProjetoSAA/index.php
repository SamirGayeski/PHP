<html>
<head>
    <title>ProjetoSAA</title>
    <link rel="icon" href="Imagens/title.ico" type="image/x-icon" />
    <meta charset="utf-8">
    <link href="Bootstrap/css/bootstrap.css" rel="stylesheet" />
    <link href="Bootstrap/css/projeto.css" rel="stylesheet" />
</head>

<body>

<!--    <div class="navbar navbar-default navbar-fixed-top">
        <div class="container">             
            <div>
                <ul class="nav navbar-nav">
                    
                    <li><a class="glyphicon glyphicon-th-list" href="View/Paciente/indexPaciente.php"> Pacientes</a></li>
                    <li><a class="glyphicon glyphicon-th-list" href="View/Convenio/indexConvenio.php"> Convênios</a></li>
                </ul>
            </div>
        </div> 
    </div>-->
    <p align="center"></p>
    <div class="container">

        <div class="principal">

            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th style="text-align: center;">Menu</th>
                    </tr>
                </thead>
                <thead>
                    <tr>
                        <th style="background-color: #f5f5f5;" align=center>
                            <a class="btn btn-block" href="View/Paciente/indexPaciente.php">
                                <font size="3"><span class="glyphicon glyphicon-plus"></span> Pacientes</a></font></th>
                    </tr>
                </thead>
                <thead>
                    <tr>
                        <th style="background-color: #f5f5f5;" align=center>
                            <a class="btn btn-block" href="View/Convenio/indexConvenio.php">
                                <font size="3"><span class="glyphicon glyphicon-plus"></span> Convênios</a></font></th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</body>
</html>